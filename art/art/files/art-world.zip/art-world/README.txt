ART WORLD — CATEGORY MARKETPLACE WEBSITE

PAGES
- index.html — Home
- paintings.html — Paintings collection
- sculptures.html — Sculptures collection
- photography.html — Photography collection
- digital-art.html — Digital Art collection
- african-art.html — African Art collection
- contact.html — Contact
- cart.html — Shopping bag
- checkout.html — Demo checkout
- confirmation.html — Demo order confirmation
- styles.css — shared styling
- script.js — shared interactions and cart logic

HOW TO RUN
1. Extract the ZIP file.
2. Keep all files in the same folder.
3. Open index.html in your browser.
4. Use the top navigation to open each independent category page.

IMPORTANT
This is a front-end prototype. Product listings and prices are sample content. Images and Google Fonts load from the internet. The shopping bag uses browser localStorage. Checkout does not process payment or send/save real orders. For a production launch, connect a secure backend, approved artwork listings, and a payment provider such as Paystack or Flutterwave.

LOGO: art-world-logo.png is created from your supplied logo and is displayed in the header of every page. Replace this PNG if you update your brand logo.

CUSTOM ARTWORK PHOTOS: Your 8 supplied images are in images/artwork-01.jpg through artwork-08.jpg. Product listing photos and add-to-bag image references use local image paths. Existing placeholder product titles, artists, and prices are still examples; update them before selling. The 8 photos repeat where there are more product cards than uploaded photos.
